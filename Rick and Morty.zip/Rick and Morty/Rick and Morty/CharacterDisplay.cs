﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Rick_and_Morty
{
    public partial class CharacterDisplay : Form
    {
        public CharacterDisplay(RickAndMorty.Net.Api.Models.Domain.Character character)
        {
            InitializeComponent();
            if (character.Name != null)
            {
                nameLabel.Text = "Character Name: " + character.Name;
                idLabel.Text = "ID: " + character.Id;
                statusLabel.Text = "Status: " + character.Status;
                originLabel.Text = "Origin: " + character.Origin.Name;
                speciesLabel.Text = "Species: " + character.Species;
                typeLabel.Text = "Type: " + character.Type;
                genderLabel.Text = "Gender: " + character.Gender.ToString();
                locationLabel.Text = "Last Known Location: " + character.Location.Name;
            }
             if (character.Image != null)
              {
            idLabel.Text = character.Image.LocalPath;
            }
            
                
        //    charImage.Image = character.;
        }

        private void CharacterDisplay_Load(object sender, EventArgs e)
        {
            InitializeComponent();
        }
    }
}
