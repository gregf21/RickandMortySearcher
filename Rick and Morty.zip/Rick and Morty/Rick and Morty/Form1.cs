﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using RickAndMorty;

namespace Rick_and_Morty
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();           
        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            idTextbox.Text = "";
        }

        private void searchButton_Click(object sender, EventArgs e)
        {
            findCharacter();
        }
        
        public async void findCharacter()
        {
            statusLabel.Text = "Loading...";
            var service = RickAndMorty.Net.Api.Factory.RickAndMortyApiFactory.Create();
            RickAndMorty.Net.Api.Models.Domain.Character x = await service.GetCharacter(1);
         //   var name = new RickAndMorty.Net.Api.Factory.RickAndMortyApiFactory;
             IEnumerable<RickAndMorty.Net.Api.Models.Domain.Character> y = await service.GetAllCharacters();
            RickAndMorty.Net.Api.Models.Domain.Character[] characterArray;
            characterArray = y.ToArray();
            RickAndMorty.Net.Api.Models.Domain.Character selectedCharacter = null;
            foreach (RickAndMorty.Net.Api.Models.Domain.Character character in characterArray)
            {
                int.TryParse(idTextbox.Text, out int n);
                if (characterTextbox.Text != "")
                {
                    if (character.Name.Contains(characterTextbox.Text))
                    {
                        selectedCharacter = character;
                    }
                }
                else
                {
                    if (character.Id == n)
                    {
                        selectedCharacter = character;
                    }
                }
            }
            if (selectedCharacter == null)
            {
                statusLabel.Text = "Character not found";
            }
            else
            {
                statusLabel.Text = "Character Found!";
                CharacterDisplay form = new CharacterDisplay(selectedCharacter);
                form.Show();
                
            }
            
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void idTextbox_TextChanged(object sender, EventArgs e)
        {
            characterTextbox.Text = "";
        }
    }
}
